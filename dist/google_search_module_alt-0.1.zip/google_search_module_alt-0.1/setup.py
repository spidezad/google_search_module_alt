from setuptools import setup

setup(name='google_search_module_alt',
      version='0.1',
      description='Google search with python',
      url='https://github.com/spidezad/google_search_module_alt',
      author='Tan Kok Hua',
      author_email='kokhua81@gmail.com',
      packages=['google_search_module_alt'],
      zip_safe=False)